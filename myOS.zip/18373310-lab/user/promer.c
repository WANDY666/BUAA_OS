#include "lib.h"

void 
umain(void)
{
	int r; 
	int mutex = syscall_init_PV_var(1);
	int empty = syscall_init_PV_var(5);
	int full = syscall_init_PV_var(0);
	int flag1 = 0;
	int flag2 = 0;
	if ((r = fork()) < 0) {
		writef("Fork failed\n");
	}		
	if (r == 0) {
		int count = 30;
		while(count--) {
			syscall_P(empty);
			syscall_P(mutex);
			writef("Producer yes, mutex: %d, full: %d\n", syscall_check_PV_value(mutex), syscall_check_PV_value(full));
			syscall_V(mutex);
			syscall_V(full);
		}
		flag1 = 1;
		
	} else {
		int count = 30;
		while(count--) {
			syscall_P(full);
			syscall_P(mutex);
			writef("Cosumer yes, mutex: %d, full: %d\n", syscall_check_PV_value(mutex), syscall_check_PV_value(full));
			syscall_V(mutex);
			syscall_V(empty);
		}
		flag2 = 1;
	}
	if (flag2 && flag1) {
		syscall_release_PV_var(mutex);
		syscall_release_PV_var(empty);
		syscall_release_PV_var(full);
	}
}
