#include "lib.h"

umain()
{
	while(1)
		writef("IDLE!");
}
