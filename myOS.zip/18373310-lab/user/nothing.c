#include "lib.h"

void 
umain(void)
{
	writef("Nothing\n");
}
