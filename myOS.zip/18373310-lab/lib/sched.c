#include <env.h>
#include <pmap.h>
#include <printf.h>

/* Overview:
 *  Implement simple round-robin scheduling.
 *
 *
 * Hints:
 *  1. The variable which is for counting should be defined as 'static'.
 *  2. Use variable 'env_sched_list', which is a pointer array.
 *  3. CANNOT use `return` statement!
 */
/*** exercise 3.14 ***/
void sched_yield(void)
{
    static int count = 0; // remaining time slices of current env
    static int point = 0; // current env_sched_list index
    /*  hint:
     *  1. if (count==0), insert `e` into `env_sched_list[1-point]`
     *     using LIST_REMOVE and LIST_INSERT_TAIL.
     *  2. if (env_sched_list[point] is empty), point = 1 - point;
     *     then search through `env_sched_list[point]` for a runnable env `e`, 
     *     and set count = e->env_pri
     *  3. count--
     *  4. env_run()
     *
     *  functions or macros below may be used (not all):
     *  LIST_INSERT_TAIL, LIST_REMOVE, LIST_FIRST, LIST_EMPTY
     */
    struct Env* env = NULL;
//	printf("sched yield start\n");
    	if (count > 0 && curenv != NULL && curenv->env_status == ENV_RUNNABLE) {
    	    count--;
//		 	printf("sched yield end, count--, count = %d, curenv still is %d, point = %d \n", count, curenv->env_id, point);
			env_run(curenv);
    	} else {
//			printf("in else 38\n");
    	    if (curenv != NULL) {
//				printf("in else 38\n");
    	        LIST_REMOVE(curenv, env_sched_link);
    	        if (curenv->env_status != ENV_FREE) {
    	        	LIST_INSERT_TAIL((env_sched_list + 1 - point), curenv, env_sched_link);
    	        }
    	    }
//			printf("in else 45\n");
			int flag = 0;
			while (!flag) {
    			LIST_FOREACH(env, env_sched_list + point, env_sched_link) {
    			    if (env->env_status == ENV_RUNNABLE) {
//						printf("find it\n");
						flag = 1;
    			        break;		
    			    }
    			}
				point = 1 - point;
			}
//			printf("in else 56\n");
			if (env) {
//				printf("in else 58\n");
//		 		printf("sched yield end, env_run(%d) \n", env->env_id);
    			count = env->env_pri - 1;
				env_run(env);
			} 
//			printf("in else 63, curenv->%d, status->%d, count->%d\n ", (curenv? curenv->env_id : -1), (curenv? curenv->env_status : -10), count);
	}
}
